import { jsPDF } from 'jspdf';
import { ClauseAnalysisResult } from '../types';

export function exportAnalysisToPdf(
  clauseText: string,
  result: ClauseAnalysisResult,
  durationSeconds: number
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 18;
  const contentWidth = pageWidth - margin * 2;
  let y = 20;

  const checkPageBreak = (neededHeight: number) => {
    if (y + neededHeight > pageHeight - 22) {
      doc.addPage();
      y = 20;
    }
  };

  // Header
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(17);
  doc.setTextColor(15, 23, 42);
  doc.text('Analisador de Cláusulas — Relatório de Revisão', margin, y);
  y += 7;

  // Metadata line
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(100, 116, 139);
  const nowStr = new Date().toLocaleString('pt-BR', {
    dateStyle: 'short',
    timeStyle: 'short',
  });
  doc.text(
    `Emitido em: ${nowStr}   |   Tempo de análise: ${durationSeconds.toFixed(2)}s`,
    margin,
    y
  );
  y += 6;

  // Mandatory Legal Notice Box
  doc.setDrawColor(203, 213, 225);
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(margin, y, contentWidth, 12, 1.5, 1.5, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(51, 65, 85);
  doc.text(
    'AVISO IMPORTANTE: Não substitui um advogado. Esta análise é automatizada e apenas informativa.',
    margin + 4,
    y + 7.5
  );
  y += 18;

  // Risk Level Section
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text(`Nível de Risco: ${result.nivelRisco.toUpperCase()}`, margin, y);
  y += 5.5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(51, 65, 85);
  const riskLines = doc.splitTextToSize(
    `Justificativa: ${result.justificativaRisco}`,
    contentWidth
  );
  doc.text(riskLines, margin, y);
  y += riskLines.length * 5 + 6;

  // 1. Resumo em até 3 linhas
  checkPageBreak(28);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11.5);
  doc.setTextColor(15, 23, 42);
  doc.text('1. Resumo em Linguagem Simples (até 3 linhas)', margin, y);
  y += 6;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(30, 41, 59);
  result.resumoLinhas.slice(0, 3).forEach((line, idx) => {
    const wrapped = doc.splitTextToSize(`${idx + 1}. ${line}`, contentWidth);
    checkPageBreak(wrapped.length * 5 + 2);
    doc.text(wrapped, margin, y);
    y += wrapped.length * 5 + 1.5;
  });
  y += 5;

  // Context & Ambiguity Check
  if (result.observacaoContexto) {
    const obsPrefix = result.possuiAmbiguidadeOuFaltaContexto
      ? 'Alerta de Ambiguidade / Falta de Contexto: '
      : 'Avaliação de Contexto: ';
    const obsLines = doc.splitTextToSize(
      `${obsPrefix}${result.observacaoContexto}`,
      contentWidth
    );
    checkPageBreak(obsLines.length * 5 + 8);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10.5);
    doc.setTextColor(15, 23, 42);
    doc.text('Verificação de Contexto e Clareza', margin, y);
    y += 5.5;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9.5);
    doc.setTextColor(51, 65, 85);
    doc.text(obsLines, margin, y);
    y += obsLines.length * 4.8 + 6;
  }

  // 2. Pontos de Atenção
  checkPageBreak(25);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11.5);
  doc.setTextColor(15, 23, 42);
  doc.text(`2. Pontos de Atenção (${result.pontosAtencao.length})`, margin, y);
  y += 6;

  if (result.pontosAtencao.length === 0) {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(71, 85, 105);
    doc.text('Nenhum ponto crítico adicional identificado neste trecho.', margin, y);
    y += 8;
  } else {
    result.pontosAtencao.forEach((pt, idx) => {
      const titleLine = `${idx + 1}. [${pt.categoria}] ${pt.titulo}`;
      const titleWrapped = doc.splitTextToSize(titleLine, contentWidth);
      const expWrapped = doc.splitTextToSize(pt.explicacao, contentWidth - 4);
      const quoteWrapped = pt.trechoRelacionado
        ? doc.splitTextToSize(`Trecho: "${pt.trechoRelacionado}"`, contentWidth - 6)
        : [];

      const blockHeight =
        titleWrapped.length * 5 +
        expWrapped.length * 4.8 +
        (quoteWrapped.length > 0 ? quoteWrapped.length * 4.5 + 3 : 0) +
        6;

      checkPageBreak(blockHeight);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(15, 23, 42);
      doc.text(titleWrapped, margin, y);
      y += titleWrapped.length * 5;

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9.5);
      doc.setTextColor(51, 65, 85);
      doc.text(expWrapped, margin + 3, y);
      y += expWrapped.length * 4.8;

      if (quoteWrapped.length > 0) {
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(9);
        doc.setTextColor(100, 116, 139);
        doc.text(quoteWrapped, margin + 4, y + 1);
        y += quoteWrapped.length * 4.5 + 2;
      }

      y += 4;
    });
  }

  // Sugestão de Negociação
  if (result.perguntaParaNegociar) {
    const negWrapped = doc.splitTextToSize(result.perguntaParaNegociar, contentWidth);
    checkPageBreak(negWrapped.length * 5 + 14);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text('3. Sugestão de Questionamento / Negociação', margin, y);
    y += 5.5;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9.5);
    doc.setTextColor(51, 65, 85);
    doc.text(negWrapped, margin, y);
    y += negWrapped.length * 5 + 6;
  }

  // Original Clause Text
  const clauseWrapped = doc.splitTextToSize(clauseText.trim(), contentWidth);
  checkPageBreak(Math.min(clauseWrapped.length * 4.5 + 16, 50));
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text('Trecho Original Analisado', margin, y);
  y += 5.5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);
  clauseWrapped.forEach((line: string) => {
    checkPageBreak(6);
    doc.text(line, margin, y);
    y += 4.5;
  });

  // Footer on every page
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, pageHeight - 14, pageWidth - margin, pageHeight - 14);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(100, 116, 139);
    doc.text(
      'Analisador de Cláusulas — Não substitui um advogado.',
      margin,
      pageHeight - 9
    );
    doc.text(`Página ${i} de ${totalPages}`, pageWidth - margin - 22, pageHeight - 9);
  }

  const timestamp = new Date().toISOString().slice(0, 10);
  doc.save(`analise-clausula-${timestamp}.pdf`);
}
